title: 我在 GitHub 上的开源项目
date: '2019-10-28 21:10:01'
updated: '2019-10-28 21:10:01'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [linux](https://github.com/DeanYang121/linux) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/DeanYang121/linux/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/DeanYang121/linux/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DeanYang121/linux/network/members "分叉数")</span>





---

### 2. [CMDB_Flask](https://github.com/DeanYang121/CMDB_Flask) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/DeanYang121/CMDB_Flask/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/DeanYang121/CMDB_Flask/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DeanYang121/CMDB_Flask/network/members "分叉数")</span>

一套简易的cmdb系统



---

### 3. [react-shop](https://github.com/DeanYang121/react-shop) <kbd title="主要编程语言">Dockerfile</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/DeanYang121/react-shop/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/DeanYang121/react-shop/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DeanYang121/react-shop/network/members "分叉数")</span>

learn



---

### 4. [dean_flutter](https://github.com/DeanYang121/dean_flutter) <kbd title="主要编程语言">Dart</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/DeanYang121/dean_flutter/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/DeanYang121/dean_flutter/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DeanYang121/dean_flutter/network/members "分叉数")</span>





---

### 5. [docker-chatroom](https://github.com/DeanYang121/docker-chatroom) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/DeanYang121/docker-chatroom/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/DeanYang121/docker-chatroom/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DeanYang121/docker-chatroom/network/members "分叉数")</span>





---

### 6. [Go_learn](https://github.com/DeanYang121/Go_learn) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/DeanYang121/Go_learn/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/DeanYang121/Go_learn/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DeanYang121/Go_learn/network/members "分叉数")</span>





---

### 7. [react-learn](https://github.com/DeanYang121/react-learn) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/DeanYang121/react-learn/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/DeanYang121/react-learn/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DeanYang121/react-learn/network/members "分叉数")</span>



